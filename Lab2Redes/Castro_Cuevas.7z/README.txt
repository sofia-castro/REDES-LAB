Instrucciones de uso:

Aplicables a la IDE Spyder en sus versiones 4 en adelante.

Para ejecutar el programa, realizar los siguientes pasos:

1) Cambio de dirección de acceso:
Modificar la variable dirHandel ubicada en la linea 109, para ello, se debe
cambiar su contenido por una linea de código con la direccion de acceso donde
se encuentra en archivo handel.wav.

ejemplo de uso:

dirHandel = "/Users/Acer/Documents/handel.wav"

2) Ejercutar código:

opción 1:

Se debe presionar el icono verde con una flecha de play, llamado Run file 
o el botón F5.

opcion 2:
En la barra superior, ubicar la pestaña titulada 'Run', hacer clic izquierdo
sobre ella y luego seleccionar nuevamente la opción 'Run'.
